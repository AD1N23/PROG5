from setuptools import setup

setup(name='pom_weather',
      version='0.0.0.2',
      description='https://github.com/AD1N23/pom_weather',
      packages=['pom_weather'],
      author_email='mpomykin@mail.ru',
      zip_safe=False)
